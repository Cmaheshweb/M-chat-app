
function sendMessage() {
    const input = document.getElementById('user-input');
    const chatBox = document.getElementById('chat-box');
    const userMessage = input.value.trim();
    if (userMessage) {
        const p = document.createElement('p');
        p.textContent = "तुम्ही: " + userMessage;
        chatBox.appendChild(p);
        input.value = "";
    }
}

function startListening() {
    const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
    recognition.lang = 'mr-IN';
    recognition.onresult = function(event) {
        document.getElementById('user-input').value = event.results[0][0].transcript;
    };
    recognition.start();
}
