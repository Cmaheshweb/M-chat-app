
let selectedAvatar = localStorage.getItem('avatar') || '';

function selectAvatar(type) {
    selectedAvatar = type;
    localStorage.setItem('avatar', type);
    updateAvatar();
}

function updateAvatar() {
    const avatarImg = document.getElementById('avatar-img');
    if (selectedAvatar === 'female') {
        avatarImg.src = 'avatar_female.jpg';
    } else if (selectedAvatar === 'male') {
        avatarImg.src = 'avatar_male.jpg';
    } else {
        avatarImg.src = '';
    }
}

function sendMessage() {
    const input = document.getElementById('user-input');
    const message = input.value;
    if (message.trim()) {
        const chatBox = document.getElementById('chat-box');
        const msgElem = document.createElement('p');
        msgElem.textContent = 'You: ' + message;
        chatBox.appendChild(msgElem);
        input.value = '';
    }
}

window.onload = updateAvatar;
